﻿一、
1.txt到7.txt是从七天会话集中使用Apriori算法获得的服务器访问频繁路径。参数设置如下：
Minimum antecedent support = 0.5，
Minimum rule confidence = 1.0，
Maximum number of antecedents = 5。

二、
finalFrequentPath.txt文本中为最终频繁路径的结果

三、
实现源码为：findFrequentPath.cpp