package DNS_Mining;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashSet;
import java.util.Set;

public class Union {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File("G://GH//Data Mining//project//Session data result");
		File[] list = file.listFiles();
		Set<String> url = new HashSet<String>();
		String resultpath = "G://GH//Data Mining//project//Union_Url.txt";
		OutputStreamWriter out = new OutputStreamWriter(
				new FileOutputStream(resultpath), "UTF-8");
		for(int i = 0; i<list.length;i++){
			File Session = new File(list[i].getAbsolutePath());
			FileReader f_reader = new FileReader(Session);
			BufferedReader b_reader = new BufferedReader(f_reader);
			String str = "";
			while((str = b_reader.readLine())!=null){
				String current[] = str.split("\t");			
				url.add(current[0]);
			}
		}
		for(String str : url){
			out.write(str+"\r\n");
		}
		out.flush();
		out.close();
	}

}
