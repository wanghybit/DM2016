package DNS_Mining;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class get_D {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File("G://GH//Data Mining//project//result_perhour");
		File[] file_list = file.listFiles();
		for (int i = 0; i < file_list.length; i++) {
			FileReader f_reader = new FileReader(file_list[i].getAbsolutePath());
			BufferedReader b_reader = new BufferedReader(f_reader);
			String result_path = "G://GH//Data Mining//project//result D//"
					+ file_list[i].getName();
			OutputStreamWriter out = new OutputStreamWriter(
					new FileOutputStream(result_path), "UTF-8");
			String str = "";
			while ((str = b_reader.readLine()) != null) {
				String[] row = str.split("\t");
				String[] new_row = new String[25];
				new_row[0] = row[0];
				for (int j = 1; j < new_row.length; j++) {
					if (j == 1) {
						new_row[j] = "0s";

					} else {
						int current = Integer.parseInt(row[j]);
						int previous = Integer.parseInt(row[j - 1]);
						if ((current - previous) > 10) {
							String time = Integer.toString(j - 1);
							new_row[j] = time + "u";
						} else if ((current - previous) < (-10)) {
							String time = Integer.toString(j - 1);
							new_row[j] = time + "d";
						} else if (Math.abs(current - previous) <= 10) {
							String time = Integer.toString(j - 1);
							new_row[j] = time + "s";
						}
					}
				}
				for (int k = 1; k < new_row.length; k++) {
					out.write(new_row[k] + " ");
				}
				out.write("\r\n");

			}
			out.flush();
			out.close();
		}
	}

}
