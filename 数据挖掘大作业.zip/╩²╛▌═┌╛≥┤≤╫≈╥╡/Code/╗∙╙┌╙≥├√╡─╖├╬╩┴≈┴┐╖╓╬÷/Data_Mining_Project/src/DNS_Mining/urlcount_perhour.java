package DNS_Mining;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class urlcount_perhour {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File("G://GH//Data Mining//project//Intersect_Url.txt");
		FileReader f_reader = new FileReader(file);
		BufferedReader b_reader = new BufferedReader(f_reader);
		String str1 = "";
		ArrayList<String> url_list = new ArrayList<String>();
		ArrayList<URL> final_url = new ArrayList<URL>();
		int count = 0;
		while ((str1 = b_reader.readLine()) != null) {
			url_list.add(str1);
		}
		// System.out.println();
		for (int j = 0; j < url_list.size(); j++) {
			File newfile = new File("G://GH//Data Mining//project//�Ự����");
			File[] session_list = newfile.listFiles();
			String resultpath = "G://GH//Data Mining//project//result_perhour//"
					+ url_list.get(j) + "_result.txt";
			OutputStreamWriter out = new OutputStreamWriter(
					new FileOutputStream(resultpath), "UTF-8");
			for (int i = 0; i < session_list.length; i++) {
				URL newurl = new URL(url_list.get(j));
				File session = new File(session_list[i].getAbsolutePath());
				FileReader new_freader = new FileReader(session);
				BufferedReader new_breader = new BufferedReader(new_freader);
				String str = "";
				while ((str = new_breader.readLine()) != null) {
					String[] current = str.split("\\|");
					String[] user = current[0].split(":");
					String time = user[0];
					switch (time) {
					case "00": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[0]++;
						}
						break;
					}
					case "01": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[1]++;
						}
						break;
					}
					case "02": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[2]++;
						}
						break;
					}
					case "03": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[3]++;
						}
						break;
					}
					case "04": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[4]++;
						}
						break;
					}
					case "05": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[5]++;
						}
						break;
					}
					case "06": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[6]++;
						}
						break;
					}
					case "07": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[7]++;
						}
						break;
					}
					case "08": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[8]++;
						}
						break;
					}
					case "09": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[9]++;
						}
						break;
					}
					case "10": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[10]++;
						}
						break;
					}
					case "11": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[11]++;
						}
						break;
					}
					case "12": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[12]++;
						}
						break;
					}
					case "13": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[13]++;
						}
						break;
					}
					case "14": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[14]++;
						}
						break;
					}
					case "15": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[15]++;
						}
						break;
					}
					case "16": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[16]++;
						}
						break;
					}
					case "17": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[17]++;
						}
						break;
					}
					case "18": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[18]++;
						}
						break;
					}
					case "19": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[19]++;
						}
						break;
					}
					case "20": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[20]++;
						}
						break;
					}
					case "21": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[21]++;
						}
						break;
					}
					case "22": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[22]++;
						}
						break;
					}
					case "23": {
						if (str.contains(url_list.get(j))) {
							newurl.count_perhour[23]++;
						}
						break;
					}
					}

				}

				out.write(newurl.urlname + "\t");
				for (int m = 0; m < 24; m++) {
					out.write(newurl.count_perhour[m] + "\t");
				}
				out.write("\r\n");
				out.flush();
			}
			out.close();
			System.out.println("Url "+(j+1)+" complete!");
		}
	}

}
