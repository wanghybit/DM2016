package DNS_Mining;

import java.awt.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Get_Final {

	public static void main(String[] args) throws IOException {
		
		
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.add(14);
		a.add(15);
		a.add(16);
		a.add(17);
		a.add(18);
		a.add(19);
		
		System.out.println(istrueSequence(a));

		
	}

	 public static void selectSort(ArrayList<Integer> numbers) {   
	        int size = numbers.size(), temp;   
	        for (int i = 0; i < size; i++) {   
	            int k = i;   
	            for (int j = size - 1; j > i; j--) {   
	                if (numbers.get(j) < numbers.get(k))   
	                    k = j;   
	            }   
	            temp = numbers.get(i);   
	            numbers.set(i, numbers.get(k)) ;   
	            numbers.set(k, temp);   
	        }   
	    }   
	 
	 public static boolean istrueSequence(ArrayList<Integer> a){
		 for(int i = 0;i<a.size();i++){
			 if(i+1<=a.size()-1){
				 if(a.get((i+1))-a.get(i)==1){
					 continue;
				 } else {
					 break;
				 }
			 }
			 
			 if(i == a.size()-1)
				 return true;
		 }
		 return false;
	 }
}
