package DNS_Mining;

public class URL {
	public String urlname = "";
	public int number = 0;
	public int count_perhour[] = new int[24];
	
	public URL (String urlname){
		this.urlname = urlname;
	}
	
	public URL(){
		
	}
}
