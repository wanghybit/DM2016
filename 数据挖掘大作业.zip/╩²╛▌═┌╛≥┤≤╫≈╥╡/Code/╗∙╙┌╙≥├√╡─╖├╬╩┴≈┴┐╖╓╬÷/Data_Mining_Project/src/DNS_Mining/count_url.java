package DNS_Mining;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class count_url {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String filepath = "G://GH//Data Mining//project//�Ự����";
		File file = new File(filepath);
		File[] Session_list = file.listFiles();
		for (int k = 0; k < Session_list.length; k++) {
			String resultpath = "G://GH//Data Mining//project//Session data result//Sessionresult_"
					+ (k + 1) + ".txt";
			OutputStreamWriter out = new OutputStreamWriter(
					new FileOutputStream(resultpath), "UTF-8");
			File CSession1 = new File(Session_list[k].getAbsolutePath());
			FileReader f_reader = new FileReader(CSession1);
			FileReader new_freader = new FileReader(CSession1);
			BufferedReader b_reader = new BufferedReader(f_reader);
			BufferedReader new_breader = new BufferedReader(new_freader);
			String str = "";
			int count = 0;
			Set<String> url_set = new HashSet<String>();
			// ArrayList<String> url_list = new ArrayList<String>();
			ArrayList<URL> final_url = new ArrayList<URL>();
			while ((str = b_reader.readLine()) != null) {
				count++;
				String data[] = str.split("\\|");
				String current[] = data[2].split("\\?");
				String url = current[current.length - 1];
				url = url.replace(" ", "");
				url_set.add(url);
			}
			for (String url : url_set) {
				URL newurl = new URL();
				newurl.urlname = url;
				final_url.add(newurl);
			}
			// System.out.println((double)count/url_set.size());
			while ((str = new_breader.readLine()) != null) {
				String data[] = str.split("\\|");
				String current[] = data[2].split("\\?");
				String url = current[current.length - 1];
				url = url.replace(" ", "");
				for (int j = 0; j < final_url.size(); j++) {
					if (url.equals(final_url.get(j).urlname))
						final_url.get(j).number = final_url.get(j).number + 1;
				}
			}
			int counturl = 0;
			for (int i = 0; i < final_url.size(); i++) {
				if (final_url.get(i).number >= 250) {
					/*System.out.println(final_url.get(i).urlname + " "
							+ final_url.get(i).number);*/
					counturl++;
					out.write(final_url.get(i).urlname + "\t"
							+ final_url.get(i).number+"\r\n");
				}
			}
			out.flush();
			out.close();
			System.out.println(counturl);
			
		}
	}

	
}
