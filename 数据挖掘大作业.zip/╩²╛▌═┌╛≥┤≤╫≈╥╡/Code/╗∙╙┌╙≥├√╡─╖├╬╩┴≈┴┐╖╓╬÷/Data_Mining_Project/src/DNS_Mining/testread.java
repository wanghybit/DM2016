package DNS_Mining;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class testread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String result_path = "G://GH//Data Mining//project//�Ự����//CSession_01_result.txt";
		File file = new File(result_path);
		FileReader f_reader;
		try {
			f_reader = new FileReader(file);

			BufferedReader b_reader = new BufferedReader(f_reader);
			String str = "";
			int count = 0;
			String IP[] = null;
			while ((str = b_reader.readLine()) != null) {
				if (count == 0)
					IP = str.split("\t");
				else {
					String[] current = str.split("\t");
					// System.out.print(current.length);
					for (int i = 0; i < current.length; i++) {
						if (current[i].equals("1"))
							System.out.print(IP[i] + " ");
					}
					System.out.println();
				}
				count++;
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
