package DNS_Mining;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class Intersect {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File(
				"G://GH//Data Mining//project//Session data result");
		File[] list = file.listFiles();
		ArrayList<String> url_1 = new ArrayList<String>();
		ArrayList<String> url_2 = new ArrayList<String>();
		ArrayList<String> url_3 = new ArrayList<String>();
		ArrayList<String> url_4 = new ArrayList<String>();
		ArrayList<String> url_5 = new ArrayList<String>();
		ArrayList<String> url_6 = new ArrayList<String>();
		ArrayList<String> url_7 = new ArrayList<String>();
		for (int i = 0; i < list.length; i++) {
			File url_file = new File(list[i].getAbsolutePath());
			FileReader f_reader = new FileReader(url_file);
			BufferedReader b_reader = new BufferedReader(f_reader);
			String str = "";
			while ((str = b_reader.readLine()) != null) {
				String current[] = str.split("\t");
				String url = current[0];
				if (i == 0)
					url_1.add(url);
				if (i == 1)
					url_2.add(url);
				if (i == 2)
					url_3.add(url);
				if (i == 3)
					url_4.add(url);
				if (i == 4)
					url_5.add(url);
				if (i == 5)
					url_6.add(url);
				if (i == 6)
					url_7.add(url);
			}
		}
		// System.out.println();
		ArrayList<String> result12=Intersect(url_1,url_2);
		ArrayList<String> result34=Intersect(url_3,url_4);
		ArrayList<String> result56=Intersect(url_5,url_6);
		ArrayList<String> result_1234 = Intersect(result12,result34);
		ArrayList<String> result_567 = Intersect(result56,url_7);
		ArrayList<String> result = Intersect(result_1234,result_567);
		String resultpath = "G://GH//Data Mining//project//Intersect_Url.txt";
		OutputStreamWriter out = new OutputStreamWriter(
				new FileOutputStream(resultpath), "UTF-8");
		for(String string : result){
			out.write(string+"\r\n");
			
		}
		out.flush();
		out.close();
 	}
	
	public static void main2(String[] args){
		ArrayList<String> a = new ArrayList<String>();
		ArrayList<String> b = new ArrayList<String>();
		a.add("1");
		a.add("2");
		a.add("3");
		a.add("4");
		b.add("3");
		b.add("4");
		b.add("6");

		ArrayList<String> result = Intersect(a,b);
		for(String str : result){
			System.out.println(str);
		}
	}
	
	public static ArrayList<String> Intersect(ArrayList<String> a,
			ArrayList<String> b) {
		ArrayList<String> result = new ArrayList<String>();
		int size_a = a.size();
		int size_b = b.size();
		if(size_b<=size_a){
			for(int i = 0;i<size_b;i++){
				for(int j = 0 ; j<size_a;j++){
					if(b.get(i).equals(a.get(j)))
						result.add(b.get(i));
						
				}
			}
		}else{
			for(int j = 0;j<size_a;j++){
				for(int i=0;i<size_b;i++){
					if(a.get(j).equals(b.get(i)))
						result.add(a.get(j));
				}
			}
		}
		return result;
	}
}
